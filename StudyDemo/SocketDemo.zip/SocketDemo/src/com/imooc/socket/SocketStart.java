package com.imooc.socket;

public class SocketStart {

	public static void main(String[] args) {

		SocketClient client=new SocketClient();
		client.showMainMenu();
}
}
